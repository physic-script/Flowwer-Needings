#version 330

// Can't moj_import in things used during startup, when resource packs don't exist.
// This is a copy of dynamicimports.glsl and projection.glsl
layout(std140) uniform DynamicTransforms {
    mat4 ModelViewMat;
    vec4 ColorModulator;
    vec3 ModelOffset;
    mat4 TextureMat;
};
layout(std140) uniform Projection {
    mat4 ProjMat;
};

in vec3 Position;
in vec4 Color;

out vec4 vertexColor;

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

    vertexColor = Color;

    // Aura: the dark gradient Minecraft draws behind in-game menus and inventories (0xC0101010 at the top,
    // 0xD0101010 at the bottom) is made fully transparent, so the world stays fully visible (no tint).
    vec4 c = Color * 255.0;
    if (all(lessThan(abs(c.rgb - vec3(16.0)), vec3(0.6))) && (abs(c.a - 192.0) < 0.6 || abs(c.a - 208.0) < 0.6)) {
        vertexColor.a = 0.0;
    }
}
