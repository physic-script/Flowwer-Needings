FLOWWER CLIENT — SAKURA RESOURCE PACK
Minecraft Java Edition 1.21.11

Install:
1. Press Win+R.
2. Enter %appdata%\.minecraft\resourcepacks
3. Put this ZIP file in that folder without extracting it.
4. In Minecraft, open Options > Resource Packs and enable Flowwer Sakura.

This pack changes the pink sakura title-screen panorama and replaces the title logo with a blocky FLOWWER CLIENT logo. Vanilla menu buttons and their positions are controlled by Minecraft itself; a client mod is required to redesign the whole menu layout.
